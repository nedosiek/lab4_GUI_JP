package org.fitness_tracker;

public class Main {
    public static void main(String[] args) {
        FitnessTracker.main(args);

    }
}
